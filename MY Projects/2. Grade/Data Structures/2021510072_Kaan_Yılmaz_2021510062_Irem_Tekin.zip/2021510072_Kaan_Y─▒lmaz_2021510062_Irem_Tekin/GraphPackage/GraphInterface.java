package GraphPackage;

import ADTPackage.QueueInterface;

public interface GraphInterface<T> extends GraphPackage.BasicGraphInterface<T>,
                                            GraphPackage.GraphAlgorithmsInterface<T> {
}
